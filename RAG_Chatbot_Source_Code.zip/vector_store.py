
import faiss
import numpy as np
import pickle
import os

def create_vector_store(chunks, embeddings):

    embeddings = np.asarray(embeddings, dtype="float32")

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatIP(dimension)
    index.add(embeddings)

    metadata = chunks

    os.makedirs("vector_store", exist_ok=True)

    faiss.write_index(index, "vector_store/document_index.faiss")

    with open("vector_store/metadata.pkl", "wb") as file:
        pickle.dump(metadata, file)

    return index, metadata


def load_vector_store():

    index_path = "vector_store/document_index.faiss"
    metadata_path = "vector_store/metadata.pkl"

    if not os.path.exists(index_path) or not os.path.exists(metadata_path):
        raise FileNotFoundError("Process your PDF documents first.")

    index = faiss.read_index(index_path)

    with open(metadata_path, "rb") as file:
        metadata = pickle.load(file)

    return index, metadata
