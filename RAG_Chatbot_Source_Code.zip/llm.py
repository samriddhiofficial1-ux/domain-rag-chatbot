
import os
from groq import Groq
from prompt import SYSTEM_PROMPT

def generate_answer(question, retrieved_chunks):

    api_key = os.getenv("GROQ_API_KEY")

    if not api_key:
        raise ValueError("Groq API key is missing.")

    client = Groq(api_key=api_key)

    context = "\n\n".join([
        f"Source: {chunk['source']}, Page: {chunk['page']}\n"
        f"Content: {chunk['text']}"
        for chunk in retrieved_chunks
    ])

    prompt = SYSTEM_PROMPT.format(
        context=context,
        question=question
    )

    response = client.chat.completions.create(
        model="openai/gpt-oss-20b",
        messages=[
            {"role": "user", "content": prompt}
        ],
        temperature=0.1,
        max_completion_tokens=1200
    )

    return response.choices[0].message.content
