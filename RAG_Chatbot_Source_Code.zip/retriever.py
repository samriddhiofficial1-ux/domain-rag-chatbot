
import numpy as np
from embeddings import embedding_model

def retrieve_relevant_chunks(question, index, metadata, top_k=5):

    question_embedding = embedding_model.encode(
        [question],
        convert_to_numpy=True,
        normalize_embeddings=True
    ).astype("float32")

    scores, indices = index.search(question_embedding, top_k)

    retrieved_chunks = []

    for score, idx in zip(scores[0], indices[0]):

        if idx == -1:
            continue

        chunk = metadata[idx].copy()
        chunk["similarity_score"] = float(score)

        retrieved_chunks.append(chunk)

    return retrieved_chunks
