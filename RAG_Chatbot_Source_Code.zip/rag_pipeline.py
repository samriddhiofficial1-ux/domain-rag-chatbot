
from document_loader import process_pdfs
from embeddings import create_embeddings
from vector_store import create_vector_store
from retriever import retrieve_relevant_chunks
from llm import generate_answer


def process_documents(uploaded_files):

    if not uploaded_files:
        raise ValueError("Please upload at least one PDF.")

    chunks = process_pdfs(uploaded_files)

    if not chunks:
        raise ValueError("No readable text found in uploaded PDFs.")

    embeddings = create_embeddings(chunks)

    index, metadata = create_vector_store(
        chunks,
        embeddings
    )

    return {
        "index": index,
        "metadata": metadata,
        "total_chunks": len(chunks)
    }


def ask_question(question, rag_data):

    if not question.strip():
        return "Please enter a question.", []

    retrieved_chunks = retrieve_relevant_chunks(
        question,
        rag_data["index"],
        rag_data["metadata"],
        top_k=5
    )

    if not retrieved_chunks:
        return (
            "I could not find this information in the uploaded documents.",
            []
        )

    answer = generate_answer(
        question,
        retrieved_chunks
    )

    sources = []

    for chunk in retrieved_chunks:
        source = {
            "document": chunk["source"],
            "page": chunk["page"],
            "similarity": round(chunk["similarity_score"], 3)
        }

        if source not in sources:
            sources.append(source)

    return answer, sources
