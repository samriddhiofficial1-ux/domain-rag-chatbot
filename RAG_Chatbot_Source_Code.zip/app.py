
import streamlit as st
from rag_pipeline import process_documents, ask_question

st.set_page_config(
    page_title="Domain-Specific RAG Chatbot",
    page_icon="📚",
    layout="wide"
)

st.title("📚 Domain-Specific RAG Chatbot")
st.caption("Upload multiple PDFs and ask questions from their content.")

if "rag_data" not in st.session_state:
    st.session_state.rag_data = None

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

with st.sidebar:
    st.header("Document Upload")

    uploaded_files = st.file_uploader(
        "Upload one or more PDF files",
        type=["pdf"],
        accept_multiple_files=True
    )

    if uploaded_files:
        st.write("Uploaded documents:")
        for file in uploaded_files:
            st.write("📄", file.name)

    if st.button("Process Documents", use_container_width=True):
        if not uploaded_files:
            st.warning("Please upload at least one PDF.")
        else:
            try:
                with st.spinner("Extracting, chunking and indexing documents..."):
                    st.session_state.rag_data = process_documents(
                        uploaded_files
                    )
                    st.session_state.chat_history = []

                st.success(
                    f"Successfully processed "
                    f"{st.session_state.rag_data['total_chunks']} chunks!"
                )

            except Exception as error:
                st.error(f"Processing failed: {error}")

    if st.button("Clear Chat", use_container_width=True):
        st.session_state.chat_history = []
        st.rerun()

    if st.button("Remove Documents", use_container_width=True):
        st.session_state.rag_data = None
        st.session_state.chat_history = []
        st.rerun()

st.divider()

st.subheader("Chat with your documents")

if st.session_state.rag_data is None:
    st.info("Upload your PDFs from the sidebar and click Process Documents.")
else:
    st.success("Your document collection is ready!")

    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

            if message.get("sources"):
                with st.expander("View sources"):
                    for source in message["sources"]:
                        st.write(
                            f"📄 {source['document']} — "
                            f"Page {source['page']}"
                        )

    question = st.chat_input("Ask a question about your PDFs...")

    if question:
        st.session_state.chat_history.append({
            "role": "user",
            "content": question
        })

        with st.chat_message("user"):
            st.markdown(question)

        with st.chat_message("assistant"):
            with st.spinner("Searching documents and generating answer..."):
                try:
                    answer, sources = ask_question(
                        question,
                        st.session_state.rag_data
                    )

                    st.markdown(answer)

                    if sources:
                        with st.expander("View sources"):
                            for source in sources:
                                st.write(
                                    f"📄 {source['document']} — "
                                    f"Page {source['page']}"
                                )

                    st.session_state.chat_history.append({
                        "role": "assistant",
                        "content": answer,
                        "sources": sources
                    })

                except Exception as error:
                    st.error(f"Something went wrong: {error}")
