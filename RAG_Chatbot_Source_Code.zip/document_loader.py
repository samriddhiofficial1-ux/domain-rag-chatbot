
from pypdf import PdfReader
from langchain_text_splitters import RecursiveCharacterTextSplitter

def process_pdfs(uploaded_files):

    all_chunks = []

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=900,
        chunk_overlap=150
    )

    for uploaded_file in uploaded_files:

        pdf = PdfReader(uploaded_file)

        for page_number, page in enumerate(pdf.pages, start=1):

            text = page.extract_text() or ""

            if not text.strip():
                continue

            chunks = splitter.split_text(text)

            for chunk in chunks:
                all_chunks.append({
                    "text": chunk,
                    "source": uploaded_file.name,
                    "page": page_number
                })

    return all_chunks
